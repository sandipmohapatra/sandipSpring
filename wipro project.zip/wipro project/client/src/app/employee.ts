export class Employee{
    id: number;
    name: string;
    age: any;
    email: string;
}