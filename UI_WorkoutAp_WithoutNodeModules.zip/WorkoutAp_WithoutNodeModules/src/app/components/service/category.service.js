"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var http_1 = require("@angular/common/http");
var of_1 = require("rxjs/observable/of");
var operators_1 = require("rxjs/operators");
var httpOptions = {
    headers: new http_1.HttpHeaders({ 'Content-Type': 'application/json' })
};
var CategoryService = (function () {
    function CategoryService(http) {
        this.http = http;
        this.getAllCategoriesUrl = 'http://user1-PC:3002/Category/'; // URL to web api
        this.updateCategoryUrl = 'http://user1-PC:3002/Category'; // URL to web api
        this.saveCategoryUrl = 'http://user1-PC:3002/Category/'; // URL to web api
        this.deleteCategoryUrl = 'http://user1-PC:3002/Category'; // URL to web api
        this.configUrl = 'assets/config.json';
    }
    /** GET Categories from the Rest API server */
    CategoryService.prototype.getAllCategories = function () {
        return this.http.get(this.getAllCategoriesUrl).pipe(operators_1.tap(function (categories) { return console.log(categories); }), operators_1.catchError(this.handleError('getAllCategoriesHttp', [])));
    };
    /** PUT: update the Category on the server */
    CategoryService.prototype.updateCategory = function (category) {
        var url = this.deleteCategoryUrl + "/" + category._id;
        console.log("category url....." + url);
        return this.http.put(url, category, httpOptions).pipe(operators_1.tap(function (_) { return console.log("updated category id=" + category._id); }), operators_1.catchError(this.handleError('updateCategory')));
    };
    /** POST: add a new Category to the server */
    CategoryService.prototype.saveCategory = function (category) {
        console.log("category" + category);
        return this.http.post(this.saveCategoryUrl, category, httpOptions).pipe(operators_1.tap(function (category) { return console.log('added category '); }), operators_1.catchError(this.handleError('Save Category')));
    };
    //w/ id=${category._id}
    /** DELETE: delete the Category from the server */
    CategoryService.prototype.deleteCategory = function (category) {
        var url = this.deleteCategoryUrl + "/" + category._id;
        console.log("category url....." + url);
        return this.http.delete(url, httpOptions).pipe(operators_1.tap(function (_) { return console.log('Deleted Category successfully'); }), operators_1.catchError(this.handleError('Delete Category')));
    };
    /**
    * Handle Http operation that failed.
    * Let the app continue.
    * @param operation - name of the operation that failed
    * @param result - optional value to return as the observable result
    */
    CategoryService.prototype.handleError = function (operation, result) {
        if (operation === void 0) { operation = 'operation'; }
        return function (error) {
            // TODO: send the error to remote logging infrastructure			
            console.log('${error.message}'); // log to console instead
            // TODO: better job of transforming error for user consumption
            console.log(operation + " failed: " + error.message);
            // Let the app keep running by returning an empty result.
            return of_1.of(result);
        };
    };
    return CategoryService;
}());
CategoryService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [http_1.HttpClient])
], CategoryService);
exports.CategoryService = CategoryService;
//# sourceMappingURL=category.service.js.map