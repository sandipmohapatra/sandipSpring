import { Component } from '@angular/core';
import { Directive, OnInit, OnDestroy, Input } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';


import {Category} from './model/Category';
import {Workout} from './model/Workout';
import {WorkoutActive} from './model/WorkoutActive';
import { WorkoutService } from './service/workout.service';

import {IMyDpOptions} from 'mydatepicker';

@Component({
  selector: 'app-root',
  templateUrl: './startEndWorkout.component.html',
  providers: [ WorkoutService],
  styleUrls: ['./public/css/app.css']
})
export class StartEndWorkComponent implements OnInit{
	
	page:string;
	workout=new Workout();
	workoutId:string;
	workoutActive=new WorkoutActive();
	activeworkout:Workout=new Workout();
	
	constructor(private workoutService: WorkoutService,private router: Router,private route: ActivatedRoute) {
		this.route.params.subscribe( params => console.log(params));
	}	
	public myDatePickerOptions: IMyDpOptions = {
        dateFormat: 'dd.mm.yyyy'
    };
	
	currentDateTime = new Date();
    settings = {
        bigBanner: true,
        timePicker: true,
        format: 'hh:mm a',
        defaultOpen: false
    }	

    public workoutDate: any = { date: { year: this.currentDateTime.getFullYear(), month: this.currentDateTime.getMonth(), day: this.currentDateTime.getDay()+1 } };	
	
	ngOnInit() {
		this.page = this.route.snapshot.paramMap.get('page');	
		this.workoutId = this.route.snapshot.paramMap.get('id');
		this.getWorkout(this.workoutId);					
		console.log(this.page+" Workout Page.......");
	}
	
	/** GET getWorkout by id. Will 404 if id not found */
	getWorkout(id: string){	
	  this.workoutService.getWorkout(id)
      .subscribe(workout => this.workout = workout);	  
	}	
  
	cancelWorkoutActive() {
        this.router.navigate(['/ViewAllWorkout']);
    }
	
	startEndWorkoutActive(){
		if(this.workoutDate!=null){
			var selectedDateTime:Date = new Date(this.workoutDate.date.day+"/"+
			this.workoutDate.date.month+"/"+this.workoutDate.date.year);			
			if(this.page=="Start"){
				this.workoutActive.startDateTm=selectedDateTime;
			}
			else{
				this.workoutActive.endDateTm=selectedDateTime;	
			}
			console.log("this.workoutActive.startEndDateTm"+selectedDateTime);			
			if(this.workoutActive!=null){				
				this.activeworkout._id=this.workoutId;					
				this.workoutActive.workout=this.activeworkout;				
				this.workoutService.saveWorkoutActive(this.workoutActive)
				.subscribe(workoutActive => {console.log("workoutActive Saved");
				  this.router.navigate(['/ViewAllWorkout']);				  
				});		 
				
			}
		}	
	}
	

}