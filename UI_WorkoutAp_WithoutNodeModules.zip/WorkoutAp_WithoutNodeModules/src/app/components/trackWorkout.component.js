"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var TrackWorkoutComponent = (function () {
    function TrackWorkoutComponent() {
        this.workoutTimeOfDay = 41;
        this.workoutTimeOfWeek = 246;
        this.workoutTimeOfMonth = 1095;
        this.barChartOptions1 = {
            responsive: false,
            display: true,
            legend: {
                labels: {
                    fontColor: "#000",
                    fontSize: 18
                }
            },
            scales: {
                yAxes: [{
                        ticks: {
                            fontColor: "#000",
                            beginAtZero: true
                        },
                        gridLines: {
                            color: "#000",
                        }
                    }],
                xAxes: [{
                        ticks: {
                            fontColor: "#000",
                        },
                        gridLines: {
                            color: "#000",
                        }
                    }]
            }
        };
        this.barChartOptions = {
            scaleShowVerticalLines: false,
            responsive: true
        };
        this.barChartLabels = ['Mon', 'Tue', 'Wed', 'Thur', 'Fri', 'Sat', 'Sun'];
        this.barChartType = 'bar';
        this.barChartLegend = true;
        this.barChartData = [
            { data: [500, 400, 600, 300, 700, 355, 840], label: 'Calories Burnt' }
        ];
    }
    // events
    TrackWorkoutComponent.prototype.chartClicked = function (e) {
        console.log(e);
    };
    TrackWorkoutComponent.prototype.chartHovered = function (e) {
        console.log(e);
    };
    return TrackWorkoutComponent;
}());
TrackWorkoutComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        templateUrl: './track.component.html',
        styleUrls: ['./public/css/app.css']
    })
], TrackWorkoutComponent);
exports.TrackWorkoutComponent = TrackWorkoutComponent;
//# sourceMappingURL=trackWorkout.component.js.map