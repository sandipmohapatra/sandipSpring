"use strict";
var Workout = (function () {
    function Workout() {
    }
    return Workout;
}());
exports.Workout = Workout;
//# sourceMappingURL=Workout.js.map