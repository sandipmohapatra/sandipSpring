"use strict";
var Category = (function () {
    function Category() {
    }
    return Category;
}());
exports.Category = Category;
//# sourceMappingURL=Category.js.map